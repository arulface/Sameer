﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3.Model
{
    public class File_Properties
    {
        public string Type { get; set; }
        public string FileName { get; set; }
        public string FilePath { get; set; }
        public string Delimeter { get; set; }
    }
}
