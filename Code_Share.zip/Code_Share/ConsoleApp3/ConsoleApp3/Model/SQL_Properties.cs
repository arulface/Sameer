﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3.Model
{
    public class SQL_Properties
    {
        public string Type { get; set; }
        public string Database { get; set; }
        public string Server { get; set; }
    }
}
